export class Imagem{

  constructor(
    nome?: string,
    listaImg?: Array<Imagem>
  ){}
}