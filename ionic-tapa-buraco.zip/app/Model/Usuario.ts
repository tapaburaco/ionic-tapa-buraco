export class Usuario {

  constructor (
    nome?: string,
    email?: string,
    senha?: string,
    cpf?: number
  ){}

}