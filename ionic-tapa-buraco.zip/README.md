# ionic-tapa-buraco

[Edit on StackBlitz ⚡️](https://stackblitz.com/edit/ionic-tapa-buraco)